var mongoose = require('mongoose');

//Dlecaramos el schema de mongodb
var datSet = new mongoose.Schema({
    date: {type: String},
    season: {type: Number},
    neutral: {type: Number},
    playoff: {type: String},
    team1: {type: String},
    team2: {type: String},
    elo1_pre: {type: Number},
    elo2_pre: {type: Number},
    elo_prob1: {type: Number},
    elo_prob2: {type: Number},
    elo1_post: {type: Number},
    elo2_post: {type: Number},
    rating1_pre: {type: Number},
    rating2_pre: {type: Number},
    pitcher1: {type: String},
    pitcher2: {type: String},
    pitcher1_rgs: {type: Number},
    pitcher2_rgs: {type: Number},
    pitcher1_adj: {type: Number},
    pitcher2_adj: {type: Number},
    rating_prob1: {type: Number},
    rating_prob2: {type: Number},
    rating1_post: {type: Number},
    rating2_post: {type: Number},
    score1: {type: Number},
    score2: {type: Number}
});

module.exports = mongoose.model('dataSet', datSet);