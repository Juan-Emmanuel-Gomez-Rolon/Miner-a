const User = require('../models/User');
var csv = require('csvtojson');
const { response } = require('../routers/userRoute');


const importUser = async(req, res) =>{
    try {
        let userData = [];

        csv({delimiter: ';'}).fromFile(req.file.path).then(async(data) =>{
            //Insertamos los encabezado a la coleccion con su Schema
            for(let x = 0; x < data.length; x++){
                 userData.push({
                    date:data[x].date,
                    season:data[x].season,
                    neutral:data[x].neutral,
                    playoff:data[x].playoff,
                    team1:data[x].team1,
                    team2:data[x].team2,
                    elo1_pre:data[x].elo1_pre,
                    elo2_pre:data[x].elo2_pre,
                    elo_prob1:data[x].elo_prob1,
                    elo_prob2:data[x].elo_prob2,
                    elo1_post:data[x].elo1_post,
                    elo2_post:data[x].elo2_post,
                    rating1_pre:data[x].rating1_pre,
                    rating2_pre:data[x].rating2_pre,
                    pitcher1:data[x].pitcher1,
                    pitcher2:data[x].pitcher2,
                    pitcher1_rgs:data[x].pitcher1_rgs,
                    pitcher2_rgs:data[x].pitcher2_rgs,
                    pitcher1_adj:data[x].pitcher1_adj,
                    pitcher2_adj:data[x].pitcher2_adj,
                    rating_prob1:data[x].rating_prob1,
                    rating_prob2:data[x].rating_prob2,
                    rating1_post:data[x]. rating1_post,
                    rating2_post:data[x]. rating2_post,
                    score1:data[x].score1,
                    score2:data[x].score2
                 });
             }
            await User.insertMany(userData);
        });
        res.send({ status:200 ,success:true, msg: 'csv imported'});
    } catch (error) {
        res.send({ status:400 ,success:false, msg: error.message});
    }
}

module.exports = {importUser}