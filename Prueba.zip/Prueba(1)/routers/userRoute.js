const express = require("express");
const user = express();

const multer = require("multer");
const path = require("path");
const bodyParser = require("body-parser");

user.use(bodyParser.urlencoded({ extended: true }));
user.use(express.static(path.resolve(__dirname, "public")));

var storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "./public/uploads");
  },
  filename: (req, file, cb) => {
    cb(null, file.originalname);
  },
});

var upload = multer({ storage: storage });
const userController = require("../controllers/userControllers");
const { default: mongoose } = require("mongoose");
const User = require("../models/User");
const { send } = require("process");
let url = "mongodb://127.0.0.1:27017/beisbol";
user.post("/User", upload.single("file"), userController.importUser);

//Connect collection
async function connectToBeisbol() {
  return mongoose.connect("mongodb://127.0.0.1:27017/beisbol", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  });
}

//Delete collection
async function deleteToCollection() {
  return mongoose.connect("mongodb://127.0.0.1:27017/beisbol", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  });
}

//Deleted collection datasets
user.post("/Delete", async function (req, res) {
  try {
    let db = await deleteToCollection();
    const collection = db.connection.collection("datasets");
    collection.drop();
    res.send({ status:200 ,success:true, msg: 'Collection Deleted'});
  } catch (error) {
    res.send({ status:400,success: false, msg: error.message});
  }
});

//Query1
user.get("/query1", async function (req, res) {
  let db = await connectToBeisbol();
  const collection = db.connection.collection("datasets");
  let filter = {};
  if (req.query.date) {
    filter["date"] = req.query.date;
  }
  if (req.query.season) {
    filter["season"] = parseInt(req.query.season, 10);
  }
  let data = await collection.find(filter).project({}).toArray();
  res.json(data);
});

//Query2
user.get("/query2", async function (req, res) {
  let db = await connectToBeisbol();
  const collection = db.connection.collection("datasets");
  let filter = {};
  if (req.query.date) {
    filter["date"] = req.query.date;
  }
  if (req.query.season) {
    filter["season"] = parseInt(req.query.season, 10);
  }
  let data = await collection.find(filter).project({}).toArray();
  res.json(data);
});

//Query3
user.get("/query3", async function (req, res) {
  let db = await connectToBeisbol();
  const collection = db.connection.collection("datasets");
  let filter = {};
  if (req.query.season) {
    filter["season"] = parseInt(req.query.season, 10);
  }
  if (req.query.pitcher1) {
    filter["pitcher1"] = req.query.pitcher1;
  }
  if (req.query.team1) {
    filter["team1"] = req.query.team1;
  }
  let data = await collection.find(filter).project({}).toArray();
  res.json(data);
});

//Query4
user.get("/query4", async function (req, res) {
  let db = await connectToBeisbol();
  const collection = db.connection.collection("datasets");
  let filter = {};
  if (req.query.season) {
    filter["season"] = parseInt(req.query.season, 10);
  }
  if (req.query.pitcher1) {
    filter["pitcher2"] = req.query.pitcher2;
  }
  if (req.query.team1) {
    filter["team2"] = req.query.team2;
  }
  let data = await collection.find(filter).project({}).toArray();
  res.json(data);
});

//Query5
user.get("/query5", async function (req, res) {
  let db = await connectToBeisbol();
  const collection = db.connection.collection("datasets");
  let filter = {};
  if (req.query.season) {
    filter["season"] = parseInt(req.query.season, 10);
  }
  if (req.query.pitcher1) {
    filter["pitcher1"] = req.query.pitcher1;
  }
  if (req.query.team1) {
    filter["team1"] = req.query.team1;
  }
  let data = await collection.find(filter).project({}).toArray();
  res.json(data);
});

module.exports = user;
